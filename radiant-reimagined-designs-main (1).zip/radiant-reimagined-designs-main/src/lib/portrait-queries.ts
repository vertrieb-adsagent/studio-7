/**
 * Canonical vite-imagetools query strings for portrait imagery.
 *
 * All portraits MUST import using these exact suffixes so that:
 *   1. The runtime output (srcset / metadata / blurred LQIP) is identical
 *      across every consumer.
 *   2. The TypeScript module declarations in `src/vite-imagetools.d.ts`
 *      always match — no drift between code and types.
 *
 * Usage:
 *   import src      from "../assets/foo.jpg" + PORTRAIT_QUERY.srcset;
 *   import meta     from "../assets/foo.jpg" + PORTRAIT_QUERY.metadata;
 *   import lqip     from "../assets/foo.jpg" + PORTRAIT_QUERY.lqip;
 *
 * (Vite resolves the concatenated string at build time.)
 */
export const PORTRAIT_QUERY = {
  /** Responsive webp srcset at 480 / 800 / 1200 px wide. */
  srcset: "?w=480;800;1200&format=webp&as=srcset",
  /** Metadata for the largest variant — gives intrinsic width/height/src. */
  metadata: "?w=1200&format=webp&as=metadata",
  /** Tiny blurred placeholder (LQIP), 24px wide. */
  lqip: "?w=24&format=webp&blur=20&as=srcset",
} as const;

import type { PortraitSource } from "@/components/ResponsivePortrait";

export type PortraitMetadata = {
  src: string;
  width: number;
  height: number;
  format: string;
};

/**
 * Combine the three imagetools imports into a single PortraitSource.
 * Keeps the LQIP extraction logic in one place.
 */
export function buildPortraitSource(
  srcset: string,
  meta: PortraitMetadata,
  lqip: string,
): PortraitSource {
  return {
    src: meta.src,
    srcset,
    width: meta.width,
    height: meta.height,
    // imagetools `as=srcset` returns "<url> <descriptor>" — keep the URL only.
    placeholder: lqip.split(" ")[0],
  };
}