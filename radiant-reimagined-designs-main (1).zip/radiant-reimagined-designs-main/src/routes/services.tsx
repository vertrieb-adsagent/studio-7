import { createFileRoute, Link } from "@tanstack/react-router";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { useState } from "react";
import styling from "../assets/styling.jpg";
import ogServices from "../assets/og-services.jpg";

export const Route = createFileRoute("/services")({
  component: ServicesPage,
  head: () => ({
    meta: [
      { title: "Preise, Coiffure Studio7 Bern" },
      { name: "description", content: "Transparente Preisliste für Schnitt, Coloration, Balayage, Make up und Hochzeitsstyling bei Coiffure Studio7 in Bern." },
      { property: "og:title", content: "Preise, Studio7 Bern" },
      { property: "og:description", content: "Transparente Preise. Handwerkliche Qualität. Persönliche Beratung." },
      { property: "og:image", content: ogServices },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:image:alt", content: "Klare Preise, offene Beratung. Coiffure Studio7 Bern." },
      { name: "twitter:image", content: ogServices },
      { name: "twitter:title", content: "Preise, Studio7 Bern" },
      { name: "twitter:description", content: "Transparente Preise. Handwerkliche Qualität. Persönliche Beratung." },
    ],
  }),
});

type PriceItem = {
  name: string;
  price: string;
  note?: string;
  description?: string;
  duration?: string;
  availability?: string;
  bookingUrl?: string;
};
type Category = {
  number: string;
  title: string;
  intro: string;
  duration: string;
  items: PriceItem[];
};

const categories: Category[] = [
  {
    number: "01",
    title: "Schnitt",
    intro: "Form, Linie, Proportion. Jeder Schnitt beginnt mit einer Beratung, und endet mit einem Look, der ohne Styling sitzt.",
    duration: "45 bis 90 Min.",
    items: [
      {
        name: "Damen Schneiden",
        price: "ab 65",
        description:
          "Klassischer Damenschnitt mit individueller Beratung zu Form und Linie. Inklusive Waschen, Schnitt und sanftem Föhnen.",
        duration: "ca. 60 Min.",
        availability: "Di bis Sa, nach Vereinbarung",
        bookingUrl: "https://www.studio7.ch/buchen?service=damen-schneiden",
      },
      { name: "Kurzhaarschnitt", price: "ab 98", note: "inkl. Waschen & Trocknen" },
      { name: "Brushing / Legen", price: "ab 55", note: "spez. Haarbad" },
      { name: "Brushing Langhaar", price: "ab 65" },
      { name: "Herren", price: "ab 75" },
    ],
  },
  {
    number: "02",
    title: "Farbe",
    intro: "Vom sanften Glanz bis zur freihändigen Balayage, Farbe als zweite Haut, abgestimmt auf Hautton, Stil und Pflegealltag.",
    duration: "60 bis 180 Min.",
    items: [
      { name: "Coloration", price: "ab 80" },
      { name: "Coloration Langhaar", price: "ab 90" },
      { name: "Folienmèches", price: "ab 110" },
      { name: "Balayage", price: "ab 130", note: "freihändige Aufhellung" },
      { name: "Umformung", price: "ab 110" },
      { name: "Mehraufwand", price: "ab 25", note: "pro angefangene 15 Min." },
    ],
  },
  {
    number: "03",
    title: "Make up & Anlass",
    intro: "Hochzeit, Shooting, besonderer Abend. Wir gestalten Looks, die in Bewegung leben, diskret, präzise, fotogen.",
    duration: "60 bis 150 Min.",
    items: [
      { name: "Hochzeit · Frisur & Make up", price: "ab 200", note: "nach Absprache" },
      { name: "Make up", price: "ab 80", note: "nach Absprache" },
      { name: "Augenbrauen Zupfen", price: "15" },
      { name: "Augenbrauen Färben", price: "15" },
      { name: "Wimpern Färben", price: "25" },
    ],
  },
];

const faqs = [
  {
    q: "Sind die Preise verbindlich?",
    a: "Alle Preise verstehen sich als Richtwert ab. Der genaue Preis hängt von Haarlänge, Dichte und Aufwand ab und wird vor jeder Behandlung gemeinsam mit Ihnen festgelegt, ohne Überraschungen an der Kasse.",
  },
  {
    q: "Wie lange dauert eine Coloration?",
    a: "Eine klassische Coloration dauert 60 bis 90 Minuten, Folienmèches und Balayage je nach Haarlänge 120 bis 180 Minuten. Wir reservieren Ihnen die volle Zeit, damit nichts gehetzt wird.",
  },
  {
    q: "Brauche ich eine Beratung vor der ersten Coloration?",
    a: "Ja, wir empfehlen ein 15 minütiges, kostenloses Vorgespräch. So können wir Hautton, Pflegezustand und Wunsch in Ruhe besprechen, und die richtige Technik wählen.",
  },
  {
    q: "Kann ich einen Termin online buchen?",
    a: "Ja. Über den Button «Online buchen» finden Sie unseren Kalender mit allen verfügbaren Zeiten. Telefonische Termine nehmen wir gerne unter +41 31 311 77 70 entgegen.",
  },
  {
    q: "Was ist Ihre Stornierungsregelung?",
    a: "Termine können bis 24 Stunden vorher kostenfrei abgesagt werden. Bei kurzfristigen Absagen oder Nichterscheinen verrechnen wir 50 % des reservierten Betrags.",
  },
  {
    q: "Welche Zahlungsmittel akzeptieren Sie?",
    a: "Bargeld, EC/Maestro, Visa, Mastercard, TWINT und Apple/Google Pay. Gutscheine können selbstverständlich angerechnet werden.",
  },
  {
    q: "Bieten Sie Hausbesuche oder Brauttermine vor Ort an?",
    a: "Für Hochzeiten und besondere Anlässe sind wir auf Anfrage auch ausserhalb des Ateliers tätig. Sprechen Sie uns gerne an, wir erstellen Ihnen eine individuelle Offerte.",
  },
];

function ServicesPage() {
  const [active, setActive] = useState<PriceItem | null>(null);
  return (
    <>
      {/* HERO */}
      <section className="pt-40 pb-16 mx-auto max-w-[1500px] px-6 lg:px-12">
        <div className="grid md:grid-cols-12 gap-10 items-end">
          <div className="md:col-span-8">
            <p className="text-[10px] tracking-widest-extra uppercase opacity-60">Preise</p>
            <h1 className="mt-6 font-serif text-6xl md:text-[8.5vw] leading-[0.95] tracking-tight">
              Klare Preise,<br/><em className="font-light">offene</em> Beratung.
            </h1>
          </div>
          <div className="md:col-span-4">
            <p className="text-muted-foreground leading-relaxed max-w-md">
              Drei Welten, ein Anspruch. Alle Preise in CHF und als Richtwert
              ab, der finale Betrag wird vor der Behandlung gemeinsam festgelegt.
            </p>
          </div>
        </div>

        {/* Quick jump */}
        <div className="mt-16 flex flex-wrap gap-3 border-t border-border pt-8">
          {categories.map((c) => (
            <a
              key={c.number}
              href={`#kat-${c.number}`}
              className="text-[10px] tracking-widest-extra uppercase border border-border px-4 py-2.5 hover:bg-foreground hover:text-background hover:border-foreground transition-colors duration-500"
            >
              <span className="opacity-50 mr-2">{c.number}</span>{c.title}
            </a>
          ))}
          <a
            href="#faq"
            className="text-[10px] tracking-widest-extra uppercase border border-border px-4 py-2.5 hover:bg-foreground hover:text-background hover:border-foreground transition-colors duration-500"
          >
            <span className="opacity-50 mr-2">04</span>FAQ
          </a>
        </div>
      </section>

      {/* PRICE CARDS */}
      <section className="mx-auto max-w-[1500px] px-6 lg:px-12 pb-32">
        <div className="grid lg:grid-cols-3 gap-6 lg:gap-8">
          {categories.map((c) => (
            <article
              key={c.number}
              id={`kat-${c.number}`}
              className="scroll-mt-32 group bg-secondary/50 hover:bg-secondary transition-colors duration-500 p-8 md:p-10 flex flex-col"
            >
              <header className="flex items-baseline justify-between border-b border-border pb-6">
                <span className="font-serif italic text-2xl opacity-40">{c.number}</span>
                <span className="text-[10px] tracking-widest-extra uppercase opacity-60">{c.duration}</span>
              </header>

              <h2 className="mt-8 font-serif text-4xl md:text-5xl leading-tight">{c.title}</h2>
              <p className="mt-4 text-sm text-muted-foreground leading-relaxed">{c.intro}</p>

              <ul className="mt-10 divide-y divide-border/70">
                {c.items.map((it) => (
                  <li key={it.name}>
                    {it.description ? (
                      <button
                        type="button"
                        onClick={() => setActive(it)}
                        className="w-full py-4 flex items-baseline justify-between gap-3 sm:gap-5 text-left group focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-current"
                      >
                        <div className="min-w-0 flex-1">
                          <p className="text-[15px] leading-snug break-words hyphens-auto group-hover:underline underline-offset-4 decoration-foreground/30">
                            {it.name}
                            <span aria-hidden className="ml-2 text-[10px] uppercase tracking-widest-extra opacity-50">
                              Details →
                            </span>
                          </p>
                          {it.note && (
                            <p className="text-[11px] mt-1 opacity-60 italic leading-snug break-words hyphens-auto">
                              {it.note}
                            </p>
                          )}
                        </div>
                        <p className="font-serif text-lg sm:text-xl shrink-0 tabular-nums whitespace-nowrap">
                          <span className="text-[10px] uppercase tracking-widest-extra opacity-60 mr-1.5">CHF</span>
                          {it.price}
                        </p>
                      </button>
                    ) : (
                      <div className="py-4 flex items-baseline justify-between gap-3 sm:gap-5">
                        <div className="min-w-0 flex-1">
                          <p className="text-[15px] leading-snug break-words hyphens-auto">{it.name}</p>
                          {it.note && (
                            <p className="text-[11px] mt-1 opacity-60 italic leading-snug break-words hyphens-auto">
                              {it.note}
                            </p>
                          )}
                        </div>
                        <p className="font-serif text-lg sm:text-xl shrink-0 tabular-nums whitespace-nowrap">
                          <span className="text-[10px] uppercase tracking-widest-extra opacity-60 mr-1.5">CHF</span>
                          {it.price}
                        </p>
                      </div>
                    )}
                  </li>
                ))}
              </ul>

              <div className="mt-auto pt-10">
                <Link
                  to="/kontakt"
                  className="text-[10px] tracking-widest-extra uppercase link-underline"
                >
                  {c.title} anfragen →
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* EDITORIAL BAND */}
      <section className="bg-foreground text-background">
        <div className="mx-auto max-w-[1500px] px-6 lg:px-12 py-24 grid md:grid-cols-12 gap-10 items-center">
          <div className="md:col-span-5">
            <div className="aspect-[4/5] overflow-hidden">
              <img src={styling} alt="Styling im Atelier" className="h-full w-full object-cover" loading="lazy" />
            </div>
          </div>
          <div className="md:col-span-7">
            <p className="text-[10px] tracking-widest-extra uppercase opacity-60">Persönlich</p>
            <p className="mt-6 font-serif text-3xl md:text-5xl leading-[1.1] tracking-tight text-balance">
              Nicht jeder Schnitt passt zu jedem Gesicht, und nicht jede Farbe
              zu jeder Haut. Deshalb beginnt jede Behandlung bei uns mit einem Gespräch.
            </p>
            <a
              href="https://www.studio7.ch"
              className="mt-12 inline-block text-[11px] uppercase tracking-widest-extra border border-current px-8 py-5 hover:bg-background hover:text-foreground transition-colors duration-500"
            >
              Termin online buchen
            </a>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="mx-auto max-w-[1500px] px-6 lg:px-12 py-32 scroll-mt-32">
        <div className="grid md:grid-cols-12 gap-12">
          <div className="md:col-span-4">
            <p className="text-[10px] tracking-widest-extra uppercase opacity-60">FAQ</p>
            <h2 className="mt-6 font-serif text-5xl md:text-6xl leading-[0.98] tracking-tight">
              Häufige<br/><em className="font-light">Fragen</em>.
            </h2>
            <p className="mt-8 text-muted-foreground leading-relaxed max-w-sm">
              Wenn Ihre Frage hier nicht beantwortet ist, schreiben Sie uns,
              wir antworten persönlich.
            </p>
            <Link
              to="/kontakt"
              className="mt-8 inline-block text-[11px] uppercase tracking-widest-extra link-underline"
            >
              Direkt fragen →
            </Link>
          </div>

          <div className="md:col-span-8">
            <Accordion type="single" collapsible className="border-t border-border">
              {faqs.map((f, i) => (
                <AccordionItem key={f.q} value={`faq-${i}`} className="border-b border-border">
                  <AccordionTrigger className="py-7 text-left hover:no-underline group">
                    <div className="flex items-baseline gap-6 flex-1 min-w-0 pr-6">
                      <span className="font-serif italic text-sm opacity-40 shrink-0">
                        {String(i + 1).padStart(2, "0")}
                      </span>
                      <span className="font-serif text-xl md:text-2xl leading-snug tracking-tight">
                        {f.q}
                      </span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="pl-12 pr-6 pb-8 text-base leading-relaxed text-muted-foreground">
                    {f.a}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </div>
      </section>

      {/* SERVICE DETAIL DIALOG */}
      <Dialog open={!!active} onOpenChange={(o) => !o && setActive(null)}>
        <DialogContent className="max-w-lg p-8 sm:p-10 gap-0 border-border bg-background">
          {active && (
            <div className="flex flex-col gap-6">
              <div>
                <p className="text-[10px] tracking-widest-extra uppercase opacity-60">Behandlung</p>
                <DialogTitle className="mt-3 font-serif text-3xl md:text-4xl font-light leading-[1.05] tracking-tight">
                  {active.name}
                </DialogTitle>
              </div>

              <div className="flex items-baseline justify-between border-y border-border py-4">
                <span className="text-[10px] tracking-widest-extra uppercase opacity-60">Ab Preis</span>
                <span className="font-serif text-2xl tabular-nums">
                  <span className="text-[10px] uppercase tracking-widest-extra opacity-60 mr-1.5">CHF</span>
                  {active.price.replace(/^ab\s*/i, "")}
                </span>
              </div>

              {active.description && (
                <DialogDescription asChild>
                  <p className="text-[15px] leading-relaxed text-muted-foreground">
                    {active.description}
                  </p>
                </DialogDescription>
              )}

              <dl className="grid grid-cols-1 sm:grid-cols-2 gap-5 pt-2">
                {active.duration && (
                  <div>
                    <dt className="text-[10px] tracking-widest-extra uppercase opacity-60">Dauer</dt>
                    <dd className="mt-2 font-serif text-lg">{active.duration}</dd>
                  </div>
                )}
                {active.availability && (
                  <div>
                    <dt className="text-[10px] tracking-widest-extra uppercase opacity-60">Verfügbarkeit</dt>
                    <dd className="mt-2 font-serif text-lg leading-snug">{active.availability}</dd>
                  </div>
                )}
              </dl>

              <div className="flex flex-wrap gap-3 pt-2">
                <a
                  href={active.bookingUrl ?? `https://www.studio7.ch/buchen?service=${encodeURIComponent(active.name)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="ds-btn ds-btn-primary"
                  onClick={() => setActive(null)}
                >
                  Online buchen
                </a>
                <Link
                  to="/kontakt"
                  onClick={() => setActive(null)}
                  className="ds-btn ds-btn-outline"
                >
                  Anfragen
                </Link>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
