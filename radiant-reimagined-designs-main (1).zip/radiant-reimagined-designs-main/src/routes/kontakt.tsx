import { createFileRoute } from "@tanstack/react-router";
import salon from "../assets/salon.jpg";
import ogKontakt from "../assets/og-kontakt.jpg";

export const Route = createFileRoute("/kontakt")({
  component: KontaktPage,
  head: () => ({
    meta: [
      { title: "Kontakt, Coiffure Studio7 Bern" },
      { name: "description", content: "Coiffure Studio7, Gerechtigkeitsgasse 31, 3011 Bern. Termin telefonisch oder online." },
      { property: "og:title", content: "Kontakt, Studio7 Bern" },
      { property: "og:description", content: "Gerechtigkeitsgasse 31, 3011 Bern." },
      { property: "og:image", content: ogKontakt },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:image:alt", content: "Coiffure Studio7, Gerechtigkeitsgasse 31, Bern." },
      { name: "twitter:image", content: ogKontakt },
      { name: "twitter:title", content: "Kontakt, Studio7 Bern" },
      { name: "twitter:description", content: "Gerechtigkeitsgasse 31, 3011 Bern." },
    ],
  }),
});

function KontaktPage() {
  return (
    <>
      <section className="pt-40 pb-16 mx-auto max-w-[1500px] px-6 lg:px-12">
        <p className="text-[10px] tracking-widest-extra uppercase opacity-60">Kontakt</p>
        <h1 className="mt-6 font-serif text-6xl md:text-[8.5vw] leading-[0.95] tracking-tight">
          Wir freuen uns<br/>auf <em className="font-light">Ihren</em> Besuch.
        </h1>
      </section>

      <section className="mx-auto max-w-[1500px] px-6 lg:px-12 grid md:grid-cols-12 gap-12 pb-32">
        <div className="md:col-span-5 space-y-12">
          <div>
            <p className="text-[10px] tracking-widest-extra uppercase opacity-60">Atelier</p>
            <p className="mt-3 font-serif text-3xl">Gerechtigkeitsgasse 31</p>
            <p className="font-serif text-3xl">3011 Bern</p>
          </div>
          <div>
            <p className="text-[10px] tracking-widest-extra uppercase opacity-60">Telefon</p>
            <a href="tel:+41313117770" className="mt-3 block font-serif text-3xl link-underline w-fit">+41 31 311 77 70</a>
          </div>
          <div>
            <p className="text-[10px] tracking-widest-extra uppercase opacity-60">E-Mail</p>
            <a href="mailto:hello@studio7.ch" className="mt-3 block font-serif text-3xl link-underline w-fit">hello@studio7.ch</a>
          </div>
          <div>
            <p className="text-[10px] tracking-widest-extra uppercase opacity-60">Öffnungszeiten</p>
            <ul className="mt-4 text-sm space-y-1.5">
              <li className="flex justify-between max-w-xs"><span>Montag</span><span className="opacity-50">geschlossen</span></li>
              <li className="flex justify-between max-w-xs"><span>Dienstag bis Freitag</span><span>9:00 bis 18:30</span></li>
              <li className="flex justify-between max-w-xs"><span>Samstag</span><span>9:00 bis 16:00</span></li>
            </ul>
          </div>
          <div className="pt-4">
            <a href="https://www.studio7.ch" className="text-[11px] uppercase tracking-widest-extra border border-current px-8 py-5 inline-block hover:bg-foreground hover:text-background transition-colors duration-500">
              Online buchen
            </a>
          </div>
        </div>

        <div className="md:col-span-7 space-y-6">
          <div className="aspect-[4/5] md:aspect-[5/6] overflow-hidden bg-muted">
            <img src={salon} alt="Studio7 Salon" className="h-full w-full object-cover" loading="lazy" />
          </div>
          <div className="aspect-[16/9] overflow-hidden bg-muted">
            <iframe
              title="Studio7 Standort"
              src="https://www.openstreetmap.org/export/embed.html?bbox=7.4555%2C46.9474%2C7.4595%2C46.9494&amp;layer=mapnik&amp;marker=46.9484%2C7.4575"
              className="h-full w-full grayscale"
              loading="lazy"
            />
          </div>
        </div>
      </section>
    </>
  );
}
