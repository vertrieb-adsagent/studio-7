import { createFileRoute, Link } from "@tanstack/react-router";
import heroImg from "../assets/hero.jpg";
import salonImg from "../assets/salon.jpg";
import stylingImg from "../assets/styling.jpg";
import ogHome from "../assets/og-home.jpg";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "Coiffure Studio7, Bern · Hair Atelier seit 1990" },
      { name: "description", content: "Editorial Hair Atelier im Herzen Berns. Schnitt, Farbe, Make up und Beratung mit handwerklicher Hingabe seit 1990." },
      { property: "og:title", content: "Coiffure Studio7, Bern" },
      { property: "og:description", content: "Editorial Hair Atelier an der Gerechtigkeitsgasse 31, Bern." },
      { property: "og:image", content: ogHome },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:image:alt", content: "Coiffure Studio7, Bern. Hair, crafted with intention." },
      { name: "twitter:image", content: ogHome },
      { name: "twitter:title", content: "Coiffure Studio7, Bern" },
      { name: "twitter:description", content: "Editorial Hair Atelier an der Gerechtigkeitsgasse 31, Bern." },
    ],
  }),
});

function Index() {
  return (
    <>
      {/* HERO */}
      <section className="on-dark relative h-[100svh] w-full overflow-hidden bg-foreground text-cream">
        <img
          src={heroImg}
          alt="Editorial portrait of long flowing hair"
          className="absolute inset-0 h-full w-full object-cover opacity-90"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-foreground/60 via-foreground/15 to-foreground/70" />

        <div className="relative z-10 h-full ds-container flex flex-col justify-between pt-32 pb-12">
          <div className="reveal">
            <p className="ds-eyebrow opacity-90">Coiffure · Bern · Est. 1990</p>
          </div>

          <div className="max-w-3xl">
            <h1 className="reveal reveal-delay-1 ds-display">
              Hair, <em className="font-light">crafted</em><br/>with intention.
            </h1>
            <p className="reveal reveal-delay-2 ds-lead mt-8 opacity-90">
              Ein kleines Atelier mit grossem Charakter, an der Gerechtigkeitsgasse 31 in Bern.
            </p>
          </div>

          <div className="reveal reveal-delay-3 flex flex-col md:flex-row md:items-end md:justify-between gap-6">
            <div className="flex flex-wrap gap-3">
              <a href="https://www.studio7.ch" className="ds-btn ds-btn-primary">
                Termin buchen
              </a>
              <Link to="/services" className="ds-btn ds-btn-outline">
                Leistungen ansehen
              </Link>
            </div>
            <div className="ds-eyebrow opacity-70">Scroll</div>
          </div>
        </div>
      </section>

      {/* MARQUEE */}
      <section className="border-y border-border overflow-hidden bg-background py-8">
        <div className="flex gap-16 marquee-track whitespace-nowrap">
          {Array.from({ length: 2 }).map((_, i) => (
            <div key={i} className="flex gap-16 items-center shrink-0 font-serif italic text-3xl md:text-5xl opacity-80">
              <span>Schnitt</span><span className="opacity-30">·</span>
              <span>Coloration</span><span className="opacity-30">·</span>
              <span>Balayage</span><span className="opacity-30">·</span>
              <span>Make up</span><span className="opacity-30">·</span>
              <span>Hochzeit</span><span className="opacity-30">·</span>
              <span>Beratung</span><span className="opacity-30">·</span>
            </div>
          ))}
        </div>
      </section>

      {/* INTRO */}
      <section className="ds-container ds-section grid md:grid-cols-12 gap-12">
        <div className="md:col-span-4">
          <p className="ds-eyebrow">Das Atelier</p>
        </div>
        <div className="md:col-span-8">
          <h2 className="ds-h2">
            Wir glauben an die ruhige Kraft eines guten Schnitts,
            an Farbe, die zu Ihnen spricht, und an eine Beratung, die zuhört.
          </h2>
          <p className="mt-10 max-w-2xl ds-body">
            Seit über drei Jahrzehnten arbeitet unser kleines Team in den historischen
            Lauben Berns. Was wir tun, ist Handwerk: präzise, persönlich und immer
            auf das Wesentliche reduziert.
          </p>
          <Link to="/team" className="ds-btn ds-btn-ghost mt-10">
            Lernen Sie das Team kennen
          </Link>
        </div>
      </section>

      {/* SPLIT IMAGES */}
      <section className="ds-container grid md:grid-cols-2 gap-6 md:gap-10">
        <div className="group relative aspect-[4/5] overflow-hidden bg-muted">
          <img src={salonImg} alt="Studio7 Atelier in Bern" className="img-zoom h-full w-full object-cover" loading="lazy" />
          <div className="absolute bottom-8 left-8 right-8 text-cream">
            <p className="ds-eyebrow opacity-90">01 · Atelier</p>
            <p className="ds-h3 mt-3">An der Gerechtigkeitsgasse</p>
          </div>
        </div>
        <div className="group relative aspect-[4/5] overflow-hidden bg-muted md:mt-24">
          <img src={stylingImg} alt="Detail eines Stylings im Atelier" className="img-zoom h-full w-full object-cover" loading="lazy" />
          <div className="absolute bottom-8 left-8 right-8 text-cream">
            <p className="ds-eyebrow opacity-90">02 · Handwerk</p>
            <p className="ds-h3 mt-3">Detailversessen</p>
          </div>
        </div>
      </section>

      {/* QUOTE */}
      <section className="mx-auto max-w-[1200px] px-6 lg:px-12 ds-section text-center">
        <p className="ds-eyebrow justify-center">Philosophie</p>
        <blockquote className="mt-10 ds-h1">
          „Ein guter Coiffeur hört zu, bevor er die Schere ansetzt.
          <em className="font-light"> Alles andere</em> ist Konsequenz.“
        </blockquote>
        <p className="mt-10 ds-eyebrow justify-center">Studio7, Bern</p>
      </section>

      {/* SERVICES TEASER */}
      <section className="bg-secondary">
        <div className="ds-container ds-section">
          <div className="flex items-end justify-between mb-16">
            <div>
              <p className="ds-eyebrow">Leistungen</p>
              <h2 className="ds-h2 mt-6">Eine Auswahl</h2>
            </div>
            <Link to="/services" className="ds-btn ds-btn-ghost hidden md:inline-flex">
              Alle Preise
            </Link>
          </div>

          <div className="grid md:grid-cols-3 gap-px bg-border">
            {[
              { n: "01", t: "Schnitt", d: "Damen, Herren, Kinder. Präzision auf Form und Gesicht abgestimmt.", p: "ab CHF 65" },
              { n: "02", t: "Coloration", d: "Balayage, Folientechnik, sanfte Farbnuancen.", p: "ab CHF 80" },
              { n: "03", t: "Hochzeit & Make up", d: "Hochsteckfrisuren und Make up nach Absprache.", p: "ab CHF 200" },
            ].map((s) => (
              <div key={s.n} className="bg-secondary p-12 hover:bg-background transition-colors duration-500 group">
                <div className="flex items-baseline justify-between">
                  <span className="font-serif italic text-2xl opacity-50">{s.n}</span>
                  <span className="text-[11px] uppercase tracking-widest-extra opacity-60 font-medium">{s.p}</span>
                </div>
                <h3 className="mt-16 ds-h3">{s.t}</h3>
                <p className="mt-4 ds-body">{s.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* GOOGLE REVIEWS */}
      <section className="bg-secondary border-y border-border">
        <div className="ds-container ds-section">
          <div className="grid md:grid-cols-12 gap-10 items-end mb-16">
            <div className="md:col-span-8">
              <p className="ds-eyebrow">Stimmen unserer Kundinnen</p>
              <h2 className="ds-h2 mt-6">
                <em className="font-light">Vertrauen,</em> seit über drei Jahrzehnten.
              </h2>
            </div>
            <div className="md:col-span-4 md:text-right">
              <div className="inline-flex flex-col md:items-end gap-3">
                <div className="flex items-center gap-3">
                  <span className="font-serif text-5xl leading-none">4,8</span>
                  <div className="flex flex-col">
                    <div className="flex gap-0.5 text-gold" aria-label="4,8 von 5 Sternen">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <svg key={i} width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                          <path d="M12 2l2.9 6.95L22 10l-5.5 4.78L18.2 22 12 18.27 5.8 22l1.7-7.22L2 10l7.1-1.05L12 2z" />
                        </svg>
                      ))}
                    </div>
                    <span className="text-[11px] uppercase tracking-widest-extra opacity-60 mt-1">Google Bewertungen</span>
                  </div>
                </div>
                <a
                  href="https://share.google/dx9SdImjG5lJeMQ3Z"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="ds-btn ds-btn-ghost"
                >
                  <svg width="16" height="16" viewBox="0 0 48 48" aria-hidden="true" className="mr-1">
                    <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>
                    <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>
                    <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/>
                    <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>
                  </svg>
                  Auf Google ansehen
                </a>
              </div>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-px bg-border">
            {[
              {
                name: "Marcel Scheidegger",
                meta: "Local Guide · 66 Bewertungen",
                quote: "Bester Haarschnitt ever. Kann ich nur empfehlen. Ich werde auf jeden Fall wieder gehen.",
              },
              {
                name: "Paola Cigana",
                meta: "4 Bewertungen",
                quote: "Ich bin sehr zufrieden mit meinem Besuch. Professionelle Arbeit, freundliche Beratung und ein tolles Ergebnis. Ich komme gerne wieder.",
              },
              {
                name: "Alina Müller",
                meta: "5 Bewertungen",
                quote: "Liebe Milka, vielen lieben Dank für die tolle Farbe und den Schnitt. Ich bin mega glücklich.",
              },
              {
                name: "Sabrina Häusler",
                meta: "10 Bewertungen",
                quote: "Der Salon ist schön, gemütlich und sauber. Die Bedienung war sehr nett und lustig. Bin sehr zufrieden mit meiner Frisur. Ich komme wieder.",
              },
              {
                name: "Saskia Milde",
                meta: "Local Guide · 16 Bewertungen",
                quote: "Sehr schöner und gemütlicher Salon. Sehr freundliches Personal und toller Service. Ich bin jedesmal sehr glücklich mit meinem Haarschnitt.",
              },
            ].map((r, i) => (
              <article
                key={r.name}
                className={`bg-secondary p-10 md:p-12 hover:bg-background transition-colors duration-500 flex flex-col ${
                  i >= 3 ? "hidden md:flex md:col-span-3 lg:col-span-1" : ""
                }`}
              >
                <div className="flex gap-0.5 text-gold mb-6" aria-label="5 von 5 Sternen">
                  {Array.from({ length: 5 }).map((_, s) => (
                    <svg key={s} width="14" height="14" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                      <path d="M12 2l2.9 6.95L22 10l-5.5 4.78L18.2 22 12 18.27 5.8 22l1.7-7.22L2 10l7.1-1.05L12 2z" />
                    </svg>
                  ))}
                </div>
                <blockquote className="ds-body font-serif italic text-xl md:text-2xl leading-snug flex-1">
                  „{r.quote}"
                </blockquote>
                <footer className="mt-8 pt-6 border-t border-border/60 flex items-center justify-between gap-4">
                  <div>
                    <p className="text-sm font-medium">{r.name}</p>
                    <p className="text-[11px] uppercase tracking-widest-extra opacity-60 mt-1">{r.meta}</p>
                  </div>
                  <a
                    href="https://share.google/dx9SdImjG5lJeMQ3Z"
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="Auf Google ansehen"
                    className="shrink-0 opacity-70 hover:opacity-100 transition-opacity"
                  >
                    <svg width="20" height="20" viewBox="0 0 48 48" aria-hidden="true">
                      <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>
                      <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>
                      <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/>
                      <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>
                    </svg>
                  </a>
                </footer>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="ds-container ds-section">
        <div className="grid md:grid-cols-12 gap-10 items-end">
          <div className="md:col-span-8">
            <p className="ds-eyebrow">Termin</p>
            <h2 className="mt-6 ds-h1">
              Schreiben Sie uns. Oder kommen Sie einfach vorbei.
            </h2>
          </div>
          <div className="md:col-span-4 flex md:justify-end">
            <a href="https://www.studio7.ch" className="ds-btn ds-btn-primary">
              Online buchen
            </a>
          </div>
        </div>
      </section>
    </>
  );
}
