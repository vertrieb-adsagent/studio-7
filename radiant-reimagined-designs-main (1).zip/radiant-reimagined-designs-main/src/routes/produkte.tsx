import { createFileRoute } from "@tanstack/react-router";
import products from "../assets/products.jpg";
import ogProdukte from "../assets/og-produkte.jpg";

export const Route = createFileRoute("/produkte")({
  component: ProduktePage,
  head: () => ({
    meta: [
      { title: "Produkte, Coiffure Studio7 Bern" },
      { name: "description", content: "Sorgfältig kuratierte Pflege und Stylingprodukte für jeden Haartyp, bei Studio7 in Bern erhältlich." },
      { property: "og:title", content: "Produkte, Studio7 Bern" },
      { property: "og:description", content: "Eine kuratierte Auswahl an Pflege und Stylingprodukten." },
      { property: "og:image", content: ogProdukte },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:image:alt", content: "Pflege, kuratiert. Coiffure Studio7 Bern." },
      { name: "twitter:image", content: ogProdukte },
      { name: "twitter:title", content: "Produkte, Studio7 Bern" },
      { name: "twitter:description", content: "Eine kuratierte Auswahl an Pflege und Stylingprodukten." },
    ],
  }),
});

const lines = [
  { brand: "Kérastase", note: "Pflege · Reparatur · Glanz" },
  { brand: "Oribe", note: "Styling · Editorial Finish" },
  { brand: "Davines", note: "Naturkosmetik · Nachhaltigkeit" },
  { brand: "Olaplex", note: "Bond Repair · Coloration" },
];

function ProduktePage() {
  return (
    <>
      <section className="pt-40 pb-16 mx-auto max-w-[1500px] px-6 lg:px-12">
        <p className="text-[10px] tracking-widest-extra uppercase opacity-60">Produkte</p>
        <h1 className="mt-6 font-serif text-6xl md:text-[8.5vw] leading-[0.95] tracking-tight">
          Pflege, die <em className="font-light">bleibt</em>.
        </h1>
      </section>

      <section className="mx-auto max-w-[1500px] px-6 lg:px-12 grid md:grid-cols-2 gap-12 pb-32">
        <div className="aspect-[4/5] overflow-hidden bg-muted">
          <img src={products} alt="Premium hair care products" className="h-full w-full object-cover" loading="lazy" />
        </div>
        <div className="md:pt-12">
          <p className="font-serif text-3xl md:text-4xl leading-[1.15] tracking-tight max-w-lg">
            Jedes Haar ist einzigartig, und verdient Pflege, die genau das versteht.
          </p>
          <p className="mt-8 text-muted-foreground leading-relaxed max-w-md">
            Wir führen eine kleine, sorgfältig zusammengestellte Auswahl an
            professionellen Marken und beraten Sie persönlich zu Anwendung und Routine.
          </p>

          <ul className="mt-14 divide-y divide-border">
            {lines.map((l, i) => (
              <li key={l.brand} className="py-6 flex items-baseline justify-between gap-6">
                <div className="flex items-baseline gap-6">
                  <span className="font-serif italic opacity-40 text-sm">{String(i+1).padStart(2,"0")}</span>
                  <span className="font-serif text-2xl">{l.brand}</span>
                </div>
                <span className="text-[11px] uppercase tracking-widest-extra opacity-70 text-right">{l.note}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>
    </>
  );
}
