import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { ResponsivePortrait, type PortraitSource } from "@/components/ResponsivePortrait";
import { buildPortraitSource, PORTRAIT_QUERY } from "@/lib/portrait-queries";
import ogTeam from "../assets/og-team.jpg";

// Standardized vite-imagetools queries, see src/lib/portrait-queries.ts.
// Vite requires `import` specifiers to be string literals, so the suffixes
// below are duplicated verbatim from PORTRAIT_QUERY. The compile-time check
// at the bottom of this file guarantees they never drift.
import t1Src from "../assets/team-1.jpg?w=480;800;1200&format=webp&as=srcset";
import t1Meta from "../assets/team-1.jpg?w=1200&format=webp&as=metadata";
import t1Lqip from "../assets/team-1.jpg?w=24&format=webp&blur=20&as=srcset";

import t2Src from "../assets/team-2.jpg?w=480;800;1200&format=webp&as=srcset";
import t2Meta from "../assets/team-2.jpg?w=1200&format=webp&as=metadata";
import t2Lqip from "../assets/team-2.jpg?w=24&format=webp&blur=20&as=srcset";

import t3Src from "../assets/team-3.jpg?w=480;800;1200&format=webp&as=srcset";
import t3Meta from "../assets/team-3.jpg?w=1200&format=webp&as=metadata";
import t3Lqip from "../assets/team-3.jpg?w=24&format=webp&blur=20&as=srcset";

// Compile-time guard: if PORTRAIT_QUERY ever changes, these literal types
// stop matching and TypeScript fails the build, forcing the imports above
// to be updated in lockstep.
type _AssertPortraitQuery = [
  "?w=480;800;1200&format=webp&as=srcset" extends typeof PORTRAIT_QUERY.srcset ? true : never,
  "?w=1200&format=webp&as=metadata" extends typeof PORTRAIT_QUERY.metadata ? true : never,
  "?w=24&format=webp&blur=20&as=srcset" extends typeof PORTRAIT_QUERY.lqip ? true : never,
];

const sources: Record<"t1" | "t2" | "t3", PortraitSource> = {
  t1: buildPortraitSource(t1Src, t1Meta, t1Lqip),
  t2: buildPortraitSource(t2Src, t2Meta, t2Lqip),
  t3: buildPortraitSource(t3Src, t3Meta, t3Lqip),
};

export const Route = createFileRoute("/team")({
  component: TeamPage,
  head: () => ({
    meta: [
      { title: "Das Team, Coiffure Studio7 Bern" },
      { name: "description", content: "Lernen Sie das Team von Coiffure Studio7 kennen, Coiffeurinnen mit Leidenschaft für Hairdesign, Farbe und Make up in Bern." },
      { property: "og:title", content: "Das Team, Studio7 Bern" },
      { property: "og:description", content: "Drei Persönlichkeiten, ein gemeinsamer Anspruch: handwerkliche Perfektion." },
      { property: "og:image", content: ogTeam },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:image:alt", content: "Drei Hände, ein Atelier. Das Team von Coiffure Studio7 Bern." },
      { name: "twitter:image", content: ogTeam },
      { name: "twitter:title", content: "Das Team, Studio7 Bern" },
      { name: "twitter:description", content: "Drei Persönlichkeiten, ein gemeinsamer Anspruch: handwerkliche Perfektion." },
    ],
  }),
});

type Member = {
  name: string;
  role: string;
  source: PortraitSource;
  since: number;
  bio: string;
  longBio: string;
  specialties: string[];
  languages: string[];
  signature: string;
};

const team: Member[] = [
  {
    name: "Maya",
    role: "Inhaberin · Master Coiffeuse",
    source: sources.t1,
    since: 1990,
    bio: "Gründerin von Studio7. Ihre Handschrift: ruhige, formgebende Schnitte und sensible Farbarbeit.",
    longBio:
      "Maya eröffnete Studio7 1990 an der Gerechtigkeitsgasse in Bern. Ausgebildet in Zürich und Paris, prägt ihr Blick für Form und Proportion bis heute jeden Schnitt im Atelier. Sie arbeitet leise, präzise und mit einer ruhigen Aufmerksamkeit, die ihre Stammkundinnen seit Jahrzehnten begleitet.",
    specialties: ["Präzisionsschnitt", "Klassische Coloration", "Beratung & Typveränderung", "Lange Haare"],
    languages: ["Deutsch", "Französisch", "Englisch"],
    signature: "Der Schnitt, der ohne Styling sitzt.",
  },
  {
    name: "Lina",
    role: "Senior Coloristin",
    source: sources.t2,
    since: 2014,
    bio: "Spezialistin für Balayage und natürliche Aufhellungen, Farbe als zweite Haut.",
    longBio:
      "Lina kam 2014 ins Atelier und ist unsere Coloristin für alles, was Tiefe und Licht braucht. Sie arbeitet freihändig, mit feiner Folientechnik und einem fast malerischen Verständnis für Übergänge. Ihre Spezialität: Farbe, die mit den Jahren mitwächst.",
    specialties: ["Balayage", "Folienmèches", "Sanfte Aufhellung", "Farbkorrektur"],
    languages: ["Deutsch", "Italienisch", "Englisch"],
    signature: "Farbe so subtil, dass sie nach Sonne aussieht.",
  },
  {
    name: "Aiko",
    role: "Stylistin · Make up",
    source: sources.t3,
    since: 2021,
    bio: "Brautstyling und editorial Looks. Versteht Form und Bewegung wie kaum eine andere.",
    longBio:
      "Aiko bringt seit 2021 die editorial Handschrift ins Studio. Ausgebildet im Bereich Bühnenbild und Make up, denkt sie Frisuren als Komposition: Volumen, Linie, Licht. Für Hochzeiten und Shootings ist sie die ruhige Hand hinter den Kulissen.",
    specialties: ["Hochzeitsfrisuren", "Make up", "Editorial Styling", "Hochsteckfrisuren"],
    languages: ["Deutsch", "Englisch", "Japanisch"],
    signature: "Ein Look, der in Bewegung lebt.",
  },
];

const currentYear = new Date().getFullYear();

function TeamPage() {
  const [active, setActive] = useState<Member | null>(null);

  return (
    <>
      <section className="pt-40 pb-24 mx-auto max-w-[1500px] px-6 lg:px-12">
        <p className="text-[10px] tracking-widest-extra uppercase opacity-60">Das Team</p>
        <h1 className="mt-6 font-serif text-6xl md:text-[9vw] leading-[0.95] tracking-tight">
          Drei Hände,<br/><em className="font-light">eine</em> Handschrift.
        </h1>
        <p className="mt-10 max-w-xl text-muted-foreground leading-relaxed">
          Wir sind ein bewusst kleines Atelier. Jede von uns bringt eine eigene
          Spezialität mit, verbunden durch denselben Anspruch an Handwerk und Beratung.
        </p>
      </section>

      <section className="mx-auto max-w-[1500px] px-6 lg:px-12 pb-32">
        <div className="grid md:grid-cols-3 gap-12 md:gap-8">
          {team.map((p, i) => {
            const years = currentYear - p.since;
            return (
              <article
                key={p.name}
                className={`group ${i === 1 ? "md:mt-24" : ""} ${i === 2 ? "md:mt-12" : ""}`}
              >
                <button
                  type="button"
                  onClick={() => setActive(p)}
                  className="block w-full text-left"
                  aria-label={`${p.name} bis Profil öffnen`}
                >
                  <ResponsivePortrait
                    source={p.source}
                    alt={`Portrait von ${p.name}`}
                    sizes="(min-width: 768px) 33vw, 100vw"
                    priority={i === 0}
                    className="aspect-[3/4]"
                    imgClassName="img-zoom"
                  >
                    <span className="absolute top-5 left-5 text-[10px] tracking-widest-extra uppercase text-cream/90">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <span className="absolute bottom-5 right-5 text-[10px] tracking-widest-extra uppercase text-cream/90 bg-foreground/30 backdrop-blur-sm px-3 py-2 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                      Profil ansehen →
                    </span>
                  </ResponsivePortrait>

                  <div className="mt-6 flex items-baseline justify-between gap-4">
                    <h2 className="font-serif text-3xl">{p.name}</h2>
                    <span className="text-[10px] tracking-widest-extra uppercase opacity-60 shrink-0">
                      Seit {p.since} · {years} J.
                    </span>
                  </div>
                  <p className="text-[11px] uppercase tracking-widest-extra opacity-70 mt-2">{p.role}</p>
                  <p className="mt-5 text-sm text-muted-foreground leading-relaxed">{p.bio}</p>
                </button>

                <ul className="mt-6 flex flex-wrap gap-2">
                  {p.specialties.map((s) => (
                    <li
                      key={s}
                      className="text-[10px] tracking-widest-extra uppercase border border-border px-3 py-1.5 opacity-80"
                    >
                      {s}
                    </li>
                  ))}
                </ul>
              </article>
            );
          })}
        </div>
      </section>

      <Dialog open={!!active} onOpenChange={(o) => !o && setActive(null)}>
        <DialogContent className="max-w-5xl w-[95vw] p-0 border-border bg-background sm:rounded-none overflow-hidden max-h-[92vh] overflow-y-auto">
          {active && (
            <div className="grid md:grid-cols-2">
              {/* Modal portrait, placeholder shows instantly, full image streams in */}
              <ResponsivePortrait
                source={active.source}
                alt={`Portrait von ${active.name}`}
                sizes="(min-width: 768px) 50vw, 95vw"
                priority
                className="aspect-[3/4] md:aspect-auto md:min-h-[640px]"
              >
                <span className="absolute top-5 left-5 text-[10px] tracking-widest-extra uppercase text-cream/90">
                  Studio7 · Bern
                </span>
              </ResponsivePortrait>

              <div className="p-8 md:p-12 lg:p-14 flex flex-col">
                <p className="text-[10px] tracking-widest-extra uppercase opacity-60">
                  Seit {active.since} · {currentYear - active.since} Jahre im Atelier
                </p>
                <DialogTitle asChild>
                  <h2 className="mt-4 font-serif font-light text-5xl md:text-6xl leading-[1] tracking-tight">
                    {active.name}
                  </h2>
                </DialogTitle>
                <p className="mt-3 text-[11px] uppercase tracking-widest-extra opacity-70">
                  {active.role}
                </p>

                <DialogDescription asChild>
                  <p className="mt-8 text-base leading-relaxed text-foreground/90">
                    {active.longBio}
                  </p>
                </DialogDescription>

                <div className="mt-10">
                  <p className="text-[10px] tracking-widest-extra uppercase opacity-60">Spezialgebiete</p>
                  <ul className="mt-4 flex flex-wrap gap-2">
                    {active.specialties.map((s) => (
                      <li
                        key={s}
                        className="text-[10px] tracking-widest-extra uppercase border border-border px-3 py-1.5"
                      >
                        {s}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="mt-8 grid grid-cols-2 gap-8">
                  <div>
                    <p className="text-[10px] tracking-widest-extra uppercase opacity-60">Sprachen</p>
                    <p className="mt-3 text-sm">{active.languages.join(" · ")}</p>
                  </div>
                  <div>
                    <p className="text-[10px] tracking-widest-extra uppercase opacity-60">Erfahrung</p>
                    <p className="mt-3 text-sm">{currentYear - active.since}+ Jahre</p>
                  </div>
                </div>

                <figure className="mt-10 border-l border-border pl-5">
                  <blockquote className="font-serif italic text-2xl leading-snug">
                    „{active.signature}“
                  </blockquote>
                </figure>

                <div className="mt-auto pt-10 flex flex-col sm:flex-row gap-3">
                  <a
                    href="https://www.studio7.ch"
                    className="text-[11px] uppercase tracking-widest-extra border border-current px-6 py-4 text-center hover:bg-foreground hover:text-background transition-colors duration-500"
                  >
                    Termin bei {active.name} buchen
                  </a>
                  <button
                    type="button"
                    onClick={() => setActive(null)}
                    className="text-[11px] uppercase tracking-widest-extra px-6 py-4 link-underline w-fit"
                  >
                    Schliessen
                  </button>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
