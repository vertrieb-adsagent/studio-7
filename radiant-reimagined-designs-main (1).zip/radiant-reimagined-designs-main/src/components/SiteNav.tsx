import { Link, useRouterState } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

const links = [
  { to: "/", label: "Studio" },
  { to: "/team", label: "Team" },
  { to: "/services", label: "Services" },
  { to: "/produkte", label: "Produkte" },
  { to: "/kontakt", label: "Kontakt" },
] as const;

export function SiteNav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const { location } = useRouterState();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => { setOpen(false); }, [location.pathname]);

  const onHome = location.pathname === "/";
  const transparent = onHome && !scrolled;

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        transparent ? "bg-transparent text-cream" : "bg-background/85 backdrop-blur-md text-foreground border-b border-border/60"
      }`}
    >
      <div className="ds-container h-16 md:h-20 flex items-center justify-between gap-4">
        <Link to="/" className="flex items-baseline gap-2 sm:gap-3 lg:gap-4 group shrink-0 min-w-0">
          <span className="ds-logo text-[1.125rem] sm:text-[1.375rem] lg:text-[1.5rem]">
            Studio<span className="italic font-light">7</span>
          </span>
          <span className="hidden lg:inline ds-eyebrow opacity-60">Bern · since 1990</span>
        </Link>

        <nav className="hidden md:flex items-center gap-6 lg:gap-9 xl:gap-12">
          {links.map((l) => {
            const active = location.pathname === l.to;
            return (
              <Link
                key={l.to}
                to={l.to}
                className={`ds-nav-link link-underline ${active ? "opacity-100" : "opacity-70 hover:opacity-100"}`}
              >
                {l.label}
              </Link>
            );
          })}
        </nav>

        <div className="hidden md:flex items-center justify-end shrink-0">
          <a
            href="https://www.studio7.ch"
            className={`ds-btn ${transparent ? "ds-btn-outline" : "ds-btn-primary"} px-4 lg:px-7 py-3 lg:py-4`}
          >
            Online buchen
          </a>
        </div>

        <Sheet open={open} onOpenChange={setOpen}>
          <SheetTrigger asChild>
            <button
              aria-label={open ? "Menu schliessen" : "Menu öffnen"}
              aria-expanded={open}
              className="md:hidden relative -mr-2 flex h-11 w-11 shrink-0 items-center justify-center rounded-full focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-current"
            >
              <span className="sr-only">Menu</span>
              <span className="relative flex flex-col gap-[6px] w-6">
                <span className={`block h-px w-6 bg-current transition-transform duration-300 ${open ? "translate-y-[7px] rotate-45" : ""}`} />
                <span className={`block h-px w-6 bg-current transition-opacity duration-200 ${open ? "opacity-0" : ""}`} />
                <span className={`block h-px w-6 bg-current transition-transform duration-300 ${open ? "-translate-y-[7px] -rotate-45" : ""}`} />
              </span>
            </button>
          </SheetTrigger>
          <SheetContent
            side="top"
            className="md:hidden top-16 h-auto max-h-[calc(100vh-4rem)] w-full border-t border-border bg-background p-0 text-foreground shadow-none"
          >
            <nav className="ds-container py-8 flex flex-col gap-5">
              <p className="ds-eyebrow opacity-60">Menu</p>
              <ul className="flex flex-col gap-4">
                {links.map((l) => (
                  <li key={l.to}>
                    <Link
                      to={l.to}
                      onClick={() => setOpen(false)}
                      className={`ds-h3 link-underline inline-block py-1 ${location.pathname === l.to ? "opacity-100" : "opacity-80"}`}
                    >
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
              <a href="https://www.studio7.ch" className="ds-btn ds-btn-primary mt-4 self-start">
                Online buchen
              </a>
            </nav>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  );
}
