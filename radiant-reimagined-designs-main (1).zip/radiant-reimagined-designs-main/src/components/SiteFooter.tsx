import { Link } from "@tanstack/react-router";

export function SiteFooter() {
  return (
    <footer className="bg-foreground text-background mt-32 on-dark">
      <div className="ds-container ds-section-tight grid gap-16 md:grid-cols-4">
        <div className="md:col-span-2">
          <p className="ds-h2">
            Coiffure <em className="not-italic font-light">Studio</em><span className="italic">7</span>
          </p>
          <p className="ds-lead mt-6 opacity-80">
            Eine kleine Adresse mit grossem Charakter. Seit 1990 begleiten wir Sie an
            der Gerechtigkeitsgasse 31 in Bern.
          </p>
        </div>

        <div className="space-y-3 ds-body text-background/80">
          <p className="ds-eyebrow opacity-60">Besuch</p>
          <p>Gerechtigkeitsgasse 31</p>
          <p>3011 Bern</p>
          <p className="opacity-70">+41 31 311 77 70</p>
        </div>

        <div className="space-y-3 ds-body text-background/80">
          <p className="ds-eyebrow opacity-60">Öffnungszeiten</p>
          <p>Di bis Fr · 9:00 bis 18:30</p>
          <p>Sa · 9:00 bis 16:00</p>
          <p className="opacity-60">Mo · geschlossen</p>
        </div>
      </div>

      <div className="border-t border-background/10">
        <div className="ds-container py-6 flex flex-col md:flex-row items-center justify-between gap-3 text-[11px] uppercase tracking-widest-extra opacity-60">
          <p>© {new Date().getFullYear()} Coiffure Studio7</p>
          <div className="flex gap-8">
            <Link to="/kontakt" className="link-underline">Impressum</Link>
            <a href="#">Instagram</a>
            <a href="#">Facebook</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
