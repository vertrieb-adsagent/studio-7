import { useEffect, useRef, useState, type CSSProperties } from "react";

export type PortraitSource = {
  /** small placeholder data URL (LQIP) */
  placeholder: string;
  /** main src (largest webp) */
  src: string;
  /** generated srcset with widths */
  srcset: string;
  width: number;
  height: number;
};

type Props = {
  source: PortraitSource;
  alt: string;
  sizes?: string;
  className?: string;
  imgClassName?: string;
  priority?: boolean;
  /**
   * Reserve layout space by aspect-ratio. Defaults to the image's intrinsic
   * width/height so the box has its final height before the placeholder or
   * full image arrive — preventing any CLS.
   * Set to `null` to opt out (e.g. when the parent constrains height).
   */
  aspectRatio?: number | string | null;
  /**
   * Distance from viewport (in px or rootMargin format) at which the image
   * starts downloading. Larger = earlier prefetch, smaller = saves data.
   * If omitted, an adaptive default is used: smaller on mobile (saves data),
   * larger on desktop (keeps the instant feel).
   */
  rootMargin?: string;
  /** Optional overlay rendered on top of the image */
  children?: React.ReactNode;
};

/**
 * Editorial portrait with LQIP placeholder + responsive srcset.
 * Placeholder is rendered as a blurred background; the real image fades in on load.
 */
export function ResponsivePortrait({
  source,
  alt,
  sizes = "(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw",
  className = "",
  imgClassName = "",
  priority = false,
  aspectRatio,
  rootMargin,
  children,
}: Props) {
  const [loaded, setLoaded] = useState(false);
  const [inView, setInView] = useState(priority);
  const containerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (priority || inView) return;
    const node = containerRef.current;
    if (!node) return;

    // Fallback: if IntersectionObserver isn't available, load immediately.
    if (typeof IntersectionObserver === "undefined") {
      setInView(true);
      return;
    }

    // Adaptive prefetch distance: smaller on mobile, larger on desktop.
    // Mobile (<640px): 150px — saves data, only prefetch what's nearly visible.
    // Tablet (<1024px): 300px — moderate buffer.
    // Desktop (>=1024px): 600px — keeps scrolling feeling instant.
    const resolvedRootMargin =
      rootMargin ??
      (typeof window !== "undefined"
        ? window.innerWidth < 640
          ? "150px"
          : window.innerWidth < 1024
            ? "300px"
            : "600px"
        : "400px");

    const io = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            setInView(true);
            io.disconnect();
            break;
          }
        }
      },
      { rootMargin: resolvedRootMargin, threshold: 0.01 },
    );
    io.observe(node);
    return () => io.disconnect();
  }, [priority, inView, rootMargin]);

  const ratio =
    aspectRatio === null
      ? undefined
      : aspectRatio ?? `${source.width} / ${source.height}`;

  const style: CSSProperties = {
    backgroundImage: `url(${source.placeholder})`,
    backgroundSize: "cover",
    backgroundPosition: "center",
    ...(ratio ? { aspectRatio: String(ratio) } : null),
  };

  return (
    <div
      ref={containerRef}
      className={`relative overflow-hidden bg-muted ${className}`}
      style={style}
    >
      {inView && (
        <img
          src={source.src}
          srcSet={source.srcset}
          sizes={sizes}
          width={source.width}
          height={source.height}
          alt={alt}
          loading={priority ? "eager" : "lazy"}
          decoding="async"
          fetchPriority={priority ? "high" : "auto"}
          onLoad={() => setLoaded(true)}
          className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-700 ${
            loaded ? "opacity-100" : "opacity-0"
          } ${imgClassName}`}
        />
      )}
      {children}
    </div>
  );
}
