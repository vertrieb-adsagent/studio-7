// Type declarations for vite-imagetools query imports.
//
// TypeScript module wildcards only allow a single `*`, so we declare by
// query suffix. Every portrait import in the project goes through the
// canonical query strings defined in `src/lib/portrait-queries.ts`, which
// keeps the runtime output and these types in lockstep.
declare module "*as=srcset" {
  const src: string;
  export default src;
}
declare module "*as=metadata" {
  const meta: {
    src: string;
    width: number;
    height: number;
    format: string;
  };
  export default meta;
}
declare module "*as=url" {
  const src: string;
  export default src;
}
